export default `
:host([hidden]) {
  display: none !important;
}
`;
