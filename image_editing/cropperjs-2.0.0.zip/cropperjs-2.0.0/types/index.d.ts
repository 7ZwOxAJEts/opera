declare module '*.css' {
  const content: string;

  export default content;
}

declare module '*.vue' {
  const content: any;

  export default content;
}
