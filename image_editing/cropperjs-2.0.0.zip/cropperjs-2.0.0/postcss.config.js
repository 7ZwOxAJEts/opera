module.exports = {
  plugins: {
    autoprefixer: {},
    stylelint: {
      fix: true,
    },
    cssnano: {
      preset: 'default',
    },
  },
};
